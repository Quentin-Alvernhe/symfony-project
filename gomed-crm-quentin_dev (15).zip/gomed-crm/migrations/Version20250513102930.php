<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

/**
 * Auto-generated Migration: Please modify to your needs!
 */
final class Version20250513102930 extends AbstractMigration
{
    public function getDescription(): string
    {
        return '';
    }

    public function up(Schema $schema): void
    {
        // this up() migration is auto-generated, please modify it to your needs
        $this->addSql(<<<'SQL'
            CREATE TABLE activite (id INT AUTO_INCREMENT NOT NULL, name VARCHAR(255) NOT NULL, created_at DATETIME(6) NOT NULL COMMENT '(DC2Type:datetime_immutable)', updated_at DATETIME(6) DEFAULT NULL, deleted_at DATETIME(6) DEFAULT NULL, PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB
        SQL);
        $this->addSql(<<<'SQL'
            CREATE TABLE activite_syndicat (activite_id INT NOT NULL, syndicat_id INT NOT NULL, INDEX IDX_DAE8901E9B0F88B1 (activite_id), INDEX IDX_DAE8901E8F5ADEED (syndicat_id), PRIMARY KEY(activite_id, syndicat_id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB
        SQL);
        $this->addSql(<<<'SQL'
            CREATE TABLE adhesion (id INT AUTO_INCREMENT NOT NULL, contact_id INT DEFAULT NULL, periode_id INT DEFAULT NULL, cotisation_id INT DEFAULT NULL, montant_don INT DEFAULT NULL, created_at DATETIME(6) NOT NULL COMMENT '(DC2Type:datetime_immutable)', updated_at DATETIME(6) DEFAULT NULL, deleted_at DATETIME(6) DEFAULT NULL, INDEX IDX_C50CA65AE7A1254A (contact_id), INDEX IDX_C50CA65AF384C1CF (periode_id), INDEX IDX_C50CA65A3EAA84B1 (cotisation_id), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB
        SQL);
        $this->addSql(<<<'SQL'
            CREATE TABLE adresse (id INT AUTO_INCREMENT NOT NULL, ligne_1 VARCHAR(255) NOT NULL, ligne_2 VARCHAR(255) DEFAULT NULL, ligne_3 VARCHAR(255) DEFAULT NULL, code_postal VARCHAR(255) NOT NULL, ville VARCHAR(255) NOT NULL, region VARCHAR(255) DEFAULT NULL, departement VARCHAR(255) DEFAULT NULL, code_pays VARCHAR(255) DEFAULT NULL, pays VARCHAR(255) DEFAULT NULL, created_at DATETIME(6) NOT NULL COMMENT '(DC2Type:datetime_immutable)', updated_at DATETIME(6) DEFAULT NULL, deleted_at DATETIME(6) DEFAULT NULL, PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB
        SQL);
        $this->addSql(<<<'SQL'
            CREATE TABLE adresse_syndicat (adresse_id INT NOT NULL, syndicat_id INT NOT NULL, INDEX IDX_276ED11C4DE7DC5C (adresse_id), INDEX IDX_276ED11C8F5ADEED (syndicat_id), PRIMARY KEY(adresse_id, syndicat_id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB
        SQL);
        $this->addSql(<<<'SQL'
            CREATE TABLE attestation (id INT AUTO_INCREMENT NOT NULL, adhesion_id INT DEFAULT NULL, fichier VARCHAR(255) NOT NULL, name VARCHAR(255) NOT NULL, description VARCHAR(255) NOT NULL, size INT NOT NULL, type VARCHAR(255) NOT NULL, original_name VARCHAR(255) NOT NULL, type_attestation VARCHAR(255) NOT NULL, created_at DATETIME(6) NOT NULL COMMENT '(DC2Type:datetime_immutable)', updated_at DATETIME(6) DEFAULT NULL, deleted_at DATETIME(6) DEFAULT NULL, INDEX IDX_326EC63FF68139D7 (adhesion_id), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB
        SQL);
        $this->addSql(<<<'SQL'
            CREATE TABLE centrale (id INT AUTO_INCREMENT NOT NULL, name VARCHAR(255) NOT NULL, created_at DATETIME(6) NOT NULL COMMENT '(DC2Type:datetime_immutable)', updated_at DATETIME(6) DEFAULT NULL, deleted_at DATETIME(6) DEFAULT NULL, PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB
        SQL);
        $this->addSql(<<<'SQL'
            CREATE TABLE centrale_syndicat (centrale_id INT NOT NULL, syndicat_id INT NOT NULL, INDEX IDX_7DE0FEB558A1D71F (centrale_id), INDEX IDX_7DE0FEB58F5ADEED (syndicat_id), PRIMARY KEY(centrale_id, syndicat_id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB
        SQL);
        $this->addSql(<<<'SQL'
            CREATE TABLE contact (id INT AUTO_INCREMENT NOT NULL, centrale_id INT DEFAULT NULL, secteur_id INT DEFAULT NULL, prenom VARCHAR(255) NOT NULL, nom VARCHAR(255) NOT NULL, commentaire LONGTEXT DEFAULT NULL, email_pro VARCHAR(255) NOT NULL, email_perso VARCHAR(255) NOT NULL, telephone_portable_pro VARCHAR(20) DEFAULT NULL, telephone_portable_perso VARCHAR(20) DEFAULT NULL, siret VARCHAR(255) DEFAULT NULL, nombre_salarie INT DEFAULT NULL, rpps VARCHAR(255) DEFAULT NULL, date_retraite DATETIME(6) DEFAULT NULL, annee_installation DATETIME(6) DEFAULT NULL, created_at DATETIME(6) NOT NULL COMMENT '(DC2Type:datetime_immutable)', updated_at DATETIME(6) DEFAULT NULL, deleted_at DATETIME(6) DEFAULT NULL, UNIQUE INDEX UNIQ_4C62E638E270F6B9 (email_pro), UNIQUE INDEX UNIQ_4C62E638202FBBAE (email_perso), INDEX IDX_4C62E63858A1D71F (centrale_id), INDEX IDX_4C62E6389F7E4405 (secteur_id), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB
        SQL);
        $this->addSql(<<<'SQL'
            CREATE TABLE contact_statut (contact_id INT NOT NULL, statut_id INT NOT NULL, INDEX IDX_75F6C73EE7A1254A (contact_id), INDEX IDX_75F6C73EF6203804 (statut_id), PRIMARY KEY(contact_id, statut_id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB
        SQL);
        $this->addSql(<<<'SQL'
            CREATE TABLE contact_activite (contact_id INT NOT NULL, activite_id INT NOT NULL, INDEX IDX_2250C982E7A1254A (contact_id), INDEX IDX_2250C9829B0F88B1 (activite_id), PRIMARY KEY(contact_id, activite_id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB
        SQL);
        $this->addSql(<<<'SQL'
            CREATE TABLE contact_specificite (contact_id INT NOT NULL, specificite_id INT NOT NULL, INDEX IDX_908DADA1E7A1254A (contact_id), INDEX IDX_908DADA145A6410E (specificite_id), PRIMARY KEY(contact_id, specificite_id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB
        SQL);
        $this->addSql(<<<'SQL'
            CREATE TABLE contact_adresse (contact_id INT NOT NULL, adresse_id INT NOT NULL, INDEX IDX_59702997E7A1254A (contact_id), INDEX IDX_597029974DE7DC5C (adresse_id), PRIMARY KEY(contact_id, adresse_id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB
        SQL);
        $this->addSql(<<<'SQL'
            CREATE TABLE contact_syndicat (contact_id INT NOT NULL, syndicat_id INT NOT NULL, INDEX IDX_DD55DDE1E7A1254A (contact_id), INDEX IDX_DD55DDE18F5ADEED (syndicat_id), PRIMARY KEY(contact_id, syndicat_id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB
        SQL);
        $this->addSql(<<<'SQL'
            CREATE TABLE cotisation (id INT AUTO_INCREMENT NOT NULL, periode_id INT DEFAULT NULL, syndicat_id INT DEFAULT NULL, nom VARCHAR(255) NOT NULL, description LONGTEXT DEFAULT NULL, montant INT NOT NULL, created_at DATETIME(6) NOT NULL COMMENT '(DC2Type:datetime_immutable)', updated_at DATETIME(6) DEFAULT NULL, deleted_at DATETIME(6) DEFAULT NULL, INDEX IDX_AE64D2EDF384C1CF (periode_id), INDEX IDX_AE64D2ED8F5ADEED (syndicat_id), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB
        SQL);
        $this->addSql(<<<'SQL'
            CREATE TABLE periode (id INT AUTO_INCREMENT NOT NULL, name VARCHAR(255) NOT NULL, started_at DATETIME(6) NOT NULL COMMENT '(DC2Type:datetime_immutable)', end_at DATETIME(6) DEFAULT NULL, PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB
        SQL);
        $this->addSql(<<<'SQL'
            CREATE TABLE role (id INT AUTO_INCREMENT NOT NULL, name VARCHAR(255) NOT NULL, PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB
        SQL);
        $this->addSql(<<<'SQL'
            CREATE TABLE secteur (id INT AUTO_INCREMENT NOT NULL, name VARCHAR(255) NOT NULL, created_at DATETIME(6) NOT NULL COMMENT '(DC2Type:datetime_immutable)', updated_at DATETIME(6) DEFAULT NULL, deleted_at DATETIME(6) DEFAULT NULL, PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB
        SQL);
        $this->addSql(<<<'SQL'
            CREATE TABLE secteur_syndicat (secteur_id INT NOT NULL, syndicat_id INT NOT NULL, INDEX IDX_A3DCAB829F7E4405 (secteur_id), INDEX IDX_A3DCAB828F5ADEED (syndicat_id), PRIMARY KEY(secteur_id, syndicat_id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB
        SQL);
        $this->addSql(<<<'SQL'
            CREATE TABLE specificite (id INT AUTO_INCREMENT NOT NULL, name VARCHAR(255) NOT NULL, created_at DATETIME(6) NOT NULL COMMENT '(DC2Type:datetime_immutable)', updated_at DATETIME(6) DEFAULT NULL, deleted_at DATETIME(6) DEFAULT NULL, PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB
        SQL);
        $this->addSql(<<<'SQL'
            CREATE TABLE specificite_syndicat (specificite_id INT NOT NULL, syndicat_id INT NOT NULL, INDEX IDX_6205F5A145A6410E (specificite_id), INDEX IDX_6205F5A18F5ADEED (syndicat_id), PRIMARY KEY(specificite_id, syndicat_id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB
        SQL);
        $this->addSql(<<<'SQL'
            CREATE TABLE statut (id INT AUTO_INCREMENT NOT NULL, name VARCHAR(255) NOT NULL, created_at DATETIME(6) NOT NULL COMMENT '(DC2Type:datetime_immutable)', updated_at DATETIME(6) DEFAULT NULL, deleted_at DATETIME(6) DEFAULT NULL, PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB
        SQL);
        $this->addSql(<<<'SQL'
            CREATE TABLE statut_syndicat (statut_id INT NOT NULL, syndicat_id INT NOT NULL, INDEX IDX_3876FDD7F6203804 (statut_id), INDEX IDX_3876FDD78F5ADEED (syndicat_id), PRIMARY KEY(statut_id, syndicat_id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB
        SQL);
        $this->addSql(<<<'SQL'
            CREATE TABLE syndicat (id INT AUTO_INCREMENT NOT NULL, contact_principale_id INT DEFAULT NULL, contact_secretariat_id INT DEFAULT NULL, contact_comptable_id INT DEFAULT NULL, nom VARCHAR(255) NOT NULL, acronyme VARCHAR(255) DEFAULT NULL, email VARCHAR(255) DEFAULT NULL, telephone VARCHAR(255) DEFAULT NULL, logo VARCHAR(255) DEFAULT NULL, banque VARCHAR(255) DEFAULT NULL, siret VARCHAR(255) DEFAULT NULL, nom_asso_don VARCHAR(255) DEFAULT NULL, created_at DATETIME(6) NOT NULL COMMENT '(DC2Type:datetime_immutable)', updated_at DATETIME(6) DEFAULT NULL, deleted_at DATETIME(6) DEFAULT NULL, INDEX IDX_47704176F46E71EE (contact_principale_id), INDEX IDX_47704176D5D54A52 (contact_secretariat_id), INDEX IDX_4770417696E5937D (contact_comptable_id), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB
        SQL);
        $this->addSql(<<<'SQL'
            CREATE TABLE user (id INT AUTO_INCREMENT NOT NULL, role_id INT DEFAULT NULL, email VARCHAR(255) NOT NULL, password VARCHAR(255) NOT NULL, prenom VARCHAR(255) NOT NULL, nom VARCHAR(255) NOT NULL, active TINYINT(1) NOT NULL, created_at DATETIME(6) NOT NULL COMMENT '(DC2Type:datetime_immutable)', updated_at DATETIME(6) DEFAULT NULL, deleted_at DATETIME(6) DEFAULT NULL, UNIQUE INDEX UNIQ_8D93D649E7927C74 (email), INDEX IDX_8D93D649D60322AC (role_id), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB
        SQL);
        $this->addSql(<<<'SQL'
            CREATE TABLE user_syndicat (user_id INT NOT NULL, syndicat_id INT NOT NULL, INDEX IDX_A7FDA576A76ED395 (user_id), INDEX IDX_A7FDA5768F5ADEED (syndicat_id), PRIMARY KEY(user_id, syndicat_id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB
        SQL);
        $this->addSql(<<<'SQL'
            CREATE TABLE messenger_messages (id BIGINT AUTO_INCREMENT NOT NULL, body LONGTEXT NOT NULL, headers LONGTEXT NOT NULL, queue_name VARCHAR(190) NOT NULL, created_at DATETIME(6) NOT NULL COMMENT '(DC2Type:datetime_immutable)', available_at DATETIME(6) NOT NULL COMMENT '(DC2Type:datetime_immutable)', delivered_at DATETIME(6) DEFAULT NULL COMMENT '(DC2Type:datetime_immutable)', INDEX IDX_75EA56E0FB7336F0 (queue_name), INDEX IDX_75EA56E0E3BD61CE (available_at), INDEX IDX_75EA56E016BA31DB (delivered_at), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB
        SQL);
        $this->addSql(<<<'SQL'
            ALTER TABLE activite_syndicat ADD CONSTRAINT FK_DAE8901E9B0F88B1 FOREIGN KEY (activite_id) REFERENCES activite (id) ON DELETE CASCADE
        SQL);
        $this->addSql(<<<'SQL'
            ALTER TABLE activite_syndicat ADD CONSTRAINT FK_DAE8901E8F5ADEED FOREIGN KEY (syndicat_id) REFERENCES syndicat (id) ON DELETE CASCADE
        SQL);
        $this->addSql(<<<'SQL'
            ALTER TABLE adhesion ADD CONSTRAINT FK_C50CA65AE7A1254A FOREIGN KEY (contact_id) REFERENCES contact (id)
        SQL);
        $this->addSql(<<<'SQL'
            ALTER TABLE adhesion ADD CONSTRAINT FK_C50CA65AF384C1CF FOREIGN KEY (periode_id) REFERENCES periode (id)
        SQL);
        $this->addSql(<<<'SQL'
            ALTER TABLE adhesion ADD CONSTRAINT FK_C50CA65A3EAA84B1 FOREIGN KEY (cotisation_id) REFERENCES cotisation (id)
        SQL);
        $this->addSql(<<<'SQL'
            ALTER TABLE adresse_syndicat ADD CONSTRAINT FK_276ED11C4DE7DC5C FOREIGN KEY (adresse_id) REFERENCES adresse (id) ON DELETE CASCADE
        SQL);
        $this->addSql(<<<'SQL'
            ALTER TABLE adresse_syndicat ADD CONSTRAINT FK_276ED11C8F5ADEED FOREIGN KEY (syndicat_id) REFERENCES syndicat (id) ON DELETE CASCADE
        SQL);
        $this->addSql(<<<'SQL'
            ALTER TABLE attestation ADD CONSTRAINT FK_326EC63FF68139D7 FOREIGN KEY (adhesion_id) REFERENCES adhesion (id)
        SQL);
        $this->addSql(<<<'SQL'
            ALTER TABLE centrale_syndicat ADD CONSTRAINT FK_7DE0FEB558A1D71F FOREIGN KEY (centrale_id) REFERENCES centrale (id) ON DELETE CASCADE
        SQL);
        $this->addSql(<<<'SQL'
            ALTER TABLE centrale_syndicat ADD CONSTRAINT FK_7DE0FEB58F5ADEED FOREIGN KEY (syndicat_id) REFERENCES syndicat (id) ON DELETE CASCADE
        SQL);
        $this->addSql(<<<'SQL'
            ALTER TABLE contact ADD CONSTRAINT FK_4C62E63858A1D71F FOREIGN KEY (centrale_id) REFERENCES centrale (id)
        SQL);
        $this->addSql(<<<'SQL'
            ALTER TABLE contact ADD CONSTRAINT FK_4C62E6389F7E4405 FOREIGN KEY (secteur_id) REFERENCES secteur (id)
        SQL);
        $this->addSql(<<<'SQL'
            ALTER TABLE contact_statut ADD CONSTRAINT FK_75F6C73EE7A1254A FOREIGN KEY (contact_id) REFERENCES contact (id) ON DELETE CASCADE
        SQL);
        $this->addSql(<<<'SQL'
            ALTER TABLE contact_statut ADD CONSTRAINT FK_75F6C73EF6203804 FOREIGN KEY (statut_id) REFERENCES statut (id) ON DELETE CASCADE
        SQL);
        $this->addSql(<<<'SQL'
            ALTER TABLE contact_activite ADD CONSTRAINT FK_2250C982E7A1254A FOREIGN KEY (contact_id) REFERENCES contact (id) ON DELETE CASCADE
        SQL);
        $this->addSql(<<<'SQL'
            ALTER TABLE contact_activite ADD CONSTRAINT FK_2250C9829B0F88B1 FOREIGN KEY (activite_id) REFERENCES activite (id) ON DELETE CASCADE
        SQL);
        $this->addSql(<<<'SQL'
            ALTER TABLE contact_specificite ADD CONSTRAINT FK_908DADA1E7A1254A FOREIGN KEY (contact_id) REFERENCES contact (id) ON DELETE CASCADE
        SQL);
        $this->addSql(<<<'SQL'
            ALTER TABLE contact_specificite ADD CONSTRAINT FK_908DADA145A6410E FOREIGN KEY (specificite_id) REFERENCES specificite (id) ON DELETE CASCADE
        SQL);
        $this->addSql(<<<'SQL'
            ALTER TABLE contact_adresse ADD CONSTRAINT FK_59702997E7A1254A FOREIGN KEY (contact_id) REFERENCES contact (id) ON DELETE CASCADE
        SQL);
        $this->addSql(<<<'SQL'
            ALTER TABLE contact_adresse ADD CONSTRAINT FK_597029974DE7DC5C FOREIGN KEY (adresse_id) REFERENCES adresse (id) ON DELETE CASCADE
        SQL);
        $this->addSql(<<<'SQL'
            ALTER TABLE contact_syndicat ADD CONSTRAINT FK_DD55DDE1E7A1254A FOREIGN KEY (contact_id) REFERENCES contact (id) ON DELETE CASCADE
        SQL);
        $this->addSql(<<<'SQL'
            ALTER TABLE contact_syndicat ADD CONSTRAINT FK_DD55DDE18F5ADEED FOREIGN KEY (syndicat_id) REFERENCES syndicat (id) ON DELETE CASCADE
        SQL);
        $this->addSql(<<<'SQL'
            ALTER TABLE cotisation ADD CONSTRAINT FK_AE64D2EDF384C1CF FOREIGN KEY (periode_id) REFERENCES periode (id)
        SQL);
        $this->addSql(<<<'SQL'
            ALTER TABLE cotisation ADD CONSTRAINT FK_AE64D2ED8F5ADEED FOREIGN KEY (syndicat_id) REFERENCES syndicat (id)
        SQL);
        $this->addSql(<<<'SQL'
            ALTER TABLE secteur_syndicat ADD CONSTRAINT FK_A3DCAB829F7E4405 FOREIGN KEY (secteur_id) REFERENCES secteur (id) ON DELETE CASCADE
        SQL);
        $this->addSql(<<<'SQL'
            ALTER TABLE secteur_syndicat ADD CONSTRAINT FK_A3DCAB828F5ADEED FOREIGN KEY (syndicat_id) REFERENCES syndicat (id) ON DELETE CASCADE
        SQL);
        $this->addSql(<<<'SQL'
            ALTER TABLE specificite_syndicat ADD CONSTRAINT FK_6205F5A145A6410E FOREIGN KEY (specificite_id) REFERENCES specificite (id) ON DELETE CASCADE
        SQL);
        $this->addSql(<<<'SQL'
            ALTER TABLE specificite_syndicat ADD CONSTRAINT FK_6205F5A18F5ADEED FOREIGN KEY (syndicat_id) REFERENCES syndicat (id) ON DELETE CASCADE
        SQL);
        $this->addSql(<<<'SQL'
            ALTER TABLE statut_syndicat ADD CONSTRAINT FK_3876FDD7F6203804 FOREIGN KEY (statut_id) REFERENCES statut (id) ON DELETE CASCADE
        SQL);
        $this->addSql(<<<'SQL'
            ALTER TABLE statut_syndicat ADD CONSTRAINT FK_3876FDD78F5ADEED FOREIGN KEY (syndicat_id) REFERENCES syndicat (id) ON DELETE CASCADE
        SQL);
        $this->addSql(<<<'SQL'
            ALTER TABLE syndicat ADD CONSTRAINT FK_47704176F46E71EE FOREIGN KEY (contact_principale_id) REFERENCES contact (id)
        SQL);
        $this->addSql(<<<'SQL'
            ALTER TABLE syndicat ADD CONSTRAINT FK_47704176D5D54A52 FOREIGN KEY (contact_secretariat_id) REFERENCES contact (id)
        SQL);
        $this->addSql(<<<'SQL'
            ALTER TABLE syndicat ADD CONSTRAINT FK_4770417696E5937D FOREIGN KEY (contact_comptable_id) REFERENCES contact (id)
        SQL);
        $this->addSql(<<<'SQL'
            ALTER TABLE user ADD CONSTRAINT FK_8D93D649D60322AC FOREIGN KEY (role_id) REFERENCES role (id)
        SQL);
        $this->addSql(<<<'SQL'
            ALTER TABLE user_syndicat ADD CONSTRAINT FK_A7FDA576A76ED395 FOREIGN KEY (user_id) REFERENCES user (id) ON DELETE CASCADE
        SQL);
        $this->addSql(<<<'SQL'
            ALTER TABLE user_syndicat ADD CONSTRAINT FK_A7FDA5768F5ADEED FOREIGN KEY (syndicat_id) REFERENCES syndicat (id) ON DELETE CASCADE
        SQL);
    }

    public function down(Schema $schema): void
    {
        // this down() migration is auto-generated, please modify it to your needs
        $this->addSql(<<<'SQL'
            ALTER TABLE activite_syndicat DROP FOREIGN KEY FK_DAE8901E9B0F88B1
        SQL);
        $this->addSql(<<<'SQL'
            ALTER TABLE activite_syndicat DROP FOREIGN KEY FK_DAE8901E8F5ADEED
        SQL);
        $this->addSql(<<<'SQL'
            ALTER TABLE adhesion DROP FOREIGN KEY FK_C50CA65AE7A1254A
        SQL);
        $this->addSql(<<<'SQL'
            ALTER TABLE adhesion DROP FOREIGN KEY FK_C50CA65AF384C1CF
        SQL);
        $this->addSql(<<<'SQL'
            ALTER TABLE adhesion DROP FOREIGN KEY FK_C50CA65A3EAA84B1
        SQL);
        $this->addSql(<<<'SQL'
            ALTER TABLE adresse_syndicat DROP FOREIGN KEY FK_276ED11C4DE7DC5C
        SQL);
        $this->addSql(<<<'SQL'
            ALTER TABLE adresse_syndicat DROP FOREIGN KEY FK_276ED11C8F5ADEED
        SQL);
        $this->addSql(<<<'SQL'
            ALTER TABLE attestation DROP FOREIGN KEY FK_326EC63FF68139D7
        SQL);
        $this->addSql(<<<'SQL'
            ALTER TABLE centrale_syndicat DROP FOREIGN KEY FK_7DE0FEB558A1D71F
        SQL);
        $this->addSql(<<<'SQL'
            ALTER TABLE centrale_syndicat DROP FOREIGN KEY FK_7DE0FEB58F5ADEED
        SQL);
        $this->addSql(<<<'SQL'
            ALTER TABLE contact DROP FOREIGN KEY FK_4C62E63858A1D71F
        SQL);
        $this->addSql(<<<'SQL'
            ALTER TABLE contact DROP FOREIGN KEY FK_4C62E6389F7E4405
        SQL);
        $this->addSql(<<<'SQL'
            ALTER TABLE contact_statut DROP FOREIGN KEY FK_75F6C73EE7A1254A
        SQL);
        $this->addSql(<<<'SQL'
            ALTER TABLE contact_statut DROP FOREIGN KEY FK_75F6C73EF6203804
        SQL);
        $this->addSql(<<<'SQL'
            ALTER TABLE contact_activite DROP FOREIGN KEY FK_2250C982E7A1254A
        SQL);
        $this->addSql(<<<'SQL'
            ALTER TABLE contact_activite DROP FOREIGN KEY FK_2250C9829B0F88B1
        SQL);
        $this->addSql(<<<'SQL'
            ALTER TABLE contact_specificite DROP FOREIGN KEY FK_908DADA1E7A1254A
        SQL);
        $this->addSql(<<<'SQL'
            ALTER TABLE contact_specificite DROP FOREIGN KEY FK_908DADA145A6410E
        SQL);
        $this->addSql(<<<'SQL'
            ALTER TABLE contact_adresse DROP FOREIGN KEY FK_59702997E7A1254A
        SQL);
        $this->addSql(<<<'SQL'
            ALTER TABLE contact_adresse DROP FOREIGN KEY FK_597029974DE7DC5C
        SQL);
        $this->addSql(<<<'SQL'
            ALTER TABLE contact_syndicat DROP FOREIGN KEY FK_DD55DDE1E7A1254A
        SQL);
        $this->addSql(<<<'SQL'
            ALTER TABLE contact_syndicat DROP FOREIGN KEY FK_DD55DDE18F5ADEED
        SQL);
        $this->addSql(<<<'SQL'
            ALTER TABLE cotisation DROP FOREIGN KEY FK_AE64D2EDF384C1CF
        SQL);
        $this->addSql(<<<'SQL'
            ALTER TABLE cotisation DROP FOREIGN KEY FK_AE64D2ED8F5ADEED
        SQL);
        $this->addSql(<<<'SQL'
            ALTER TABLE secteur_syndicat DROP FOREIGN KEY FK_A3DCAB829F7E4405
        SQL);
        $this->addSql(<<<'SQL'
            ALTER TABLE secteur_syndicat DROP FOREIGN KEY FK_A3DCAB828F5ADEED
        SQL);
        $this->addSql(<<<'SQL'
            ALTER TABLE specificite_syndicat DROP FOREIGN KEY FK_6205F5A145A6410E
        SQL);
        $this->addSql(<<<'SQL'
            ALTER TABLE specificite_syndicat DROP FOREIGN KEY FK_6205F5A18F5ADEED
        SQL);
        $this->addSql(<<<'SQL'
            ALTER TABLE statut_syndicat DROP FOREIGN KEY FK_3876FDD7F6203804
        SQL);
        $this->addSql(<<<'SQL'
            ALTER TABLE statut_syndicat DROP FOREIGN KEY FK_3876FDD78F5ADEED
        SQL);
        $this->addSql(<<<'SQL'
            ALTER TABLE syndicat DROP FOREIGN KEY FK_47704176F46E71EE
        SQL);
        $this->addSql(<<<'SQL'
            ALTER TABLE syndicat DROP FOREIGN KEY FK_47704176D5D54A52
        SQL);
        $this->addSql(<<<'SQL'
            ALTER TABLE syndicat DROP FOREIGN KEY FK_4770417696E5937D
        SQL);
        $this->addSql(<<<'SQL'
            ALTER TABLE user DROP FOREIGN KEY FK_8D93D649D60322AC
        SQL);
        $this->addSql(<<<'SQL'
            ALTER TABLE user_syndicat DROP FOREIGN KEY FK_A7FDA576A76ED395
        SQL);
        $this->addSql(<<<'SQL'
            ALTER TABLE user_syndicat DROP FOREIGN KEY FK_A7FDA5768F5ADEED
        SQL);
        $this->addSql(<<<'SQL'
            DROP TABLE activite
        SQL);
        $this->addSql(<<<'SQL'
            DROP TABLE activite_syndicat
        SQL);
        $this->addSql(<<<'SQL'
            DROP TABLE adhesion
        SQL);
        $this->addSql(<<<'SQL'
            DROP TABLE adresse
        SQL);
        $this->addSql(<<<'SQL'
            DROP TABLE adresse_syndicat
        SQL);
        $this->addSql(<<<'SQL'
            DROP TABLE attestation
        SQL);
        $this->addSql(<<<'SQL'
            DROP TABLE centrale
        SQL);
        $this->addSql(<<<'SQL'
            DROP TABLE centrale_syndicat
        SQL);
        $this->addSql(<<<'SQL'
            DROP TABLE contact
        SQL);
        $this->addSql(<<<'SQL'
            DROP TABLE contact_statut
        SQL);
        $this->addSql(<<<'SQL'
            DROP TABLE contact_activite
        SQL);
        $this->addSql(<<<'SQL'
            DROP TABLE contact_specificite
        SQL);
        $this->addSql(<<<'SQL'
            DROP TABLE contact_adresse
        SQL);
        $this->addSql(<<<'SQL'
            DROP TABLE contact_syndicat
        SQL);
        $this->addSql(<<<'SQL'
            DROP TABLE cotisation
        SQL);
        $this->addSql(<<<'SQL'
            DROP TABLE periode
        SQL);
        $this->addSql(<<<'SQL'
            DROP TABLE role
        SQL);
        $this->addSql(<<<'SQL'
            DROP TABLE secteur
        SQL);
        $this->addSql(<<<'SQL'
            DROP TABLE secteur_syndicat
        SQL);
        $this->addSql(<<<'SQL'
            DROP TABLE specificite
        SQL);
        $this->addSql(<<<'SQL'
            DROP TABLE specificite_syndicat
        SQL);
        $this->addSql(<<<'SQL'
            DROP TABLE statut
        SQL);
        $this->addSql(<<<'SQL'
            DROP TABLE statut_syndicat
        SQL);
        $this->addSql(<<<'SQL'
            DROP TABLE syndicat
        SQL);
        $this->addSql(<<<'SQL'
            DROP TABLE user
        SQL);
        $this->addSql(<<<'SQL'
            DROP TABLE user_syndicat
        SQL);
        $this->addSql(<<<'SQL'
            DROP TABLE messenger_messages
        SQL);
    }
}
